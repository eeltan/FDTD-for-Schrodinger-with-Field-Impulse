% mainfig2.m
% source code to generate plots in Fig. 2.
% Schrodinger Equation with Gauge-Invariant Field-Impulse Replacing Potentials and Computation Using LOD-FDTD Method
% by E. L. Tan and D. Y. Heh, Aug 2024

clear all
close all



%run LOD program
LOD3D



x=[-ie/2:ie/2]*dx*1e9;
y=[-je/2:je/2]*dy*1e9;
z=[-ke/2:ke/2]*dz*1e9;


%plot results
figure(011)

t = tiledlayout(2,2,'TileSpacing','Compact','Padding','Compact');
set (gcf, 'Position', [10 10 1*800 700])

nexttile
[X,Y]=meshgrid(x,y);
X=interp2(X);
Y=interp2(Y);
repsitf2D=interp2(real(squeeze(psi(:,:,ke/2))));
h=pcolor(X,Y,repsitf2D.');
set(h, 'EdgeColor', 'none');
shading flat
axis square
grid off
box off
% xlim([0 ie]*dx*1e9)
% ylim([0 je]*dy*1e9)
% clim([-3.1e11 3.1e11])
colorbar
title('\bf(a) \rm Re$(\Psi)$','interpreter','latex','fontsize',14)
%title('(a) Re(\psi)')
xlabel('$x$ (nm)','interpreter','latex','fontsize',14)
ylabel('$y$ (nm)','interpreter','latex','fontsize',14)
set(gca,'fontsize',14)
set(gcf,'Color','w');


nexttile
[X,Y]=meshgrid(x,y);
X=interp2(X);
Y=interp2(Y);
repsitf2D=interp2(imag(squeeze(psi(:,:,ke/2))));
h=pcolor(X,Y,repsitf2D.');
set(h, 'EdgeColor', 'none');
shading flat
axis square
grid off
box off
% xlim([0 ie]*dx*1e9)
% ylim([0 je]*dy*1e9)
% clim([0 2e11])
colorbar
colorbar
title('\bf(b) \rm Im$(\Psi)$','interpreter','latex','fontsize',14)
xlabel('$x$ (nm)','interpreter','latex','fontsize',14)
ylabel('$y$ (nm)','interpreter','latex','fontsize',14)
set(gca,'fontsize',14)
set(gcf,'Color','w');




nexttile
[Y,Z]=meshgrid(y,z);
Y=interp2(Y);
Z=interp2(Z);
repsitf2D=interp2(real(squeeze(psi(round(32),:,:))));
h=pcolor(Y,Z,repsitf2D.');
set(h, 'EdgeColor', 'none');
shading flat
axis square
grid off
box off
% xlim([0 ie]*dx*1e9)
% ylim([0 je]*dy*1e9)
% clim([-3.1e11 3.1e11])
colorbar
title('\bf(c) \rm Re$(\Psi)$','interpreter','latex','fontsize',14)
xlabel('$y$ (nm)','interpreter','latex','fontsize',14)
ylabel('$z$ (nm)','interpreter','latex','fontsize',14)
set(gca,'fontsize',14)
set(gcf,'Color','w');


nexttile
[Y,Z]=meshgrid(y,z);
Y=interp2(Y);
Z=interp2(Z);
repsitf2D=interp2(imag(squeeze(psi(round(32),:,:))));
h=pcolor(Y,Z,repsitf2D.');
set(h, 'EdgeColor', 'none');
shading flat
axis square
grid off
box off
% xlim([0 ie]*dx*1e9)
% ylim([0 je]*dy*1e9)
% clim([0 2e11])
colorbar
colorbar
title('\bf(d) \rm Im$(\Psi)$','interpreter','latex','fontsize',14)
xlabel('$y$ (nm)','interpreter','latex','fontsize',14)
ylabel('$z$ (nm)','interpreter','latex','fontsize',14)
set(gca,'fontsize',14)
set(gcf,'Color','w');

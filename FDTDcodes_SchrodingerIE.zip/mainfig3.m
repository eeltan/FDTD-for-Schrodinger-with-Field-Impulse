% mainfig3.m
% source code to generate plots in Fig. 3.
% Schrodinger Equation with Gauge-Invariant Field-Impulse Replacing Potentials and Computation Using LOD-FDTD Method
% by E. L. Tan and D. Y. Heh, Aug 2024

clear all
close all


%constants in SI
h=6.62607015e-34;
hbar=h/2/pi;
e=1.60217663e-19;
m=9.1093837e-31*0.067;%meff of GaAs is 0.067*me


E0=5.4e-3;%in eV
E0=E0*e;% in Joule
omega0=E0/hbar;



count=0;
for ii=0:10
count=count+1;
B0 = ii%in Tesla

omegac=e*B0/m;

%ground state
n=0;
l=0;
E=l*hbar*omegac/2+hbar*sqrt(omegac^2/4+omega0^2)*(2*n+abs(l)+1)+1*0.5*hbar*omega0;
Efock0(count)=1/e*E; %in eV

%excited state 1
n=0;
l=-1;
E=l*hbar*omegac/2+hbar*sqrt(omegac^2/4+omega0^2)*(2*n+abs(l)+1)+1*0.5*hbar*omega0;
Efock1(count)=1/e*E; %in eV

%excited state 2
n=0;
l=1;
E=l*hbar*omegac/2+hbar*sqrt(omegac^2/4+omega0^2)*(2*n+abs(l)+1)+1*0.5*hbar*omega0;
Efock2(count)=1/e*E; %in eV


LOD3D_Estate0
Elod0(count)=mean(real(energy));


LOD3D_Estate1
Elod1(count)=mean(real(energy));

LOD3D_Estate2
Elod2(count)=mean(real(energy));

end

Ba=[0:10];

plot(Ba,1000*Elod0,'k','Linewidth',2);hold on
plot(Ba,1000*Elod1,'--r','Linewidth',2);hold on
plot(Ba,1000*Elod2,':b','Linewidth',2);hold on
plot(Ba,1000*Efock0,'kx','Linewidth',2,'MarkerSize',8);hold on
plot(Ba,1000*Efock1,'xk','Linewidth',2,'MarkerSize',8);hold on
plot(Ba,1000*Efock2,'kx','Linewidth',2,'MarkerSize',8);hold on
legend('LOD-FDTD (Ground state)','LOD-FDTD (Excited state 1)','LOD-FDTD (Excited state 2)','Analytical','Location','Northwest','NumColumns',1)
xlabel('\it B \rm (T)'); 
ylabel('Energy (meV)');
set(gca,'fontsize',14)
set(gcf,'Color','w');



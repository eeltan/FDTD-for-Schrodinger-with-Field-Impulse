% mainfig4.m
% source code to generate plots in Fig. 4.
% Schrodinger Equation with Gauge-Invariant Field-Impulse Replacing Potentials and Computation Using LOD-FDTD Method
% by E. L. Tan and D. Y. Heh, Aug 2024

close all
clear all


LOD3D_multistate

figure(111)

t = tiledlayout(3,1,'TileSpacing','Compact','Padding','Compact');
set (gcf, 'Position', [10 10 1*400 1*1200])


nexttile
plot([dt:dt:dt*length(psirecord)]*1e12,real(psirecord),'k','Linewidth',2);hold on
plot([dt:10*dt:dt*length(psirecord)]*1e12,real(psianarecord(1:10:length(psirecord))),'xk','Linewidth',2,'MarkerSize',8);hold on
legend('LOD-FDTD','Analytical','Location','Northwest','NumColumns',2)
xlim([0 length(psirecord)]*dt*1e12)
ylim([-2e11 2.6e11])
% xlabel('Time (ps)'); 
ylabel('Re(\Psi)');
set(gca,'fontsize',14)
set(gcf,'Color','w');
title('(a)','fontsize',14)


nexttile
plot([dt:dt:dt*length(psirecord)]*1e12,imag(psirecord),'k','Linewidth',2);hold on
plot([dt:10*dt:dt*length(psirecord)]*1e12,imag(psianarecord(1:10:length(psirecord))),'xk','Linewidth',2,'MarkerSize',8);hold on
legend('LOD-FDTD','Analytical','Location','Northwest','NumColumns',2)
xlim([0 length(psirecord)]*dt*1e12)
ylim([-2e11 2.6e11])
% xlabel('Time (ps)'); 
ylabel('Im(\Psi)');
set(gca,'fontsize',14)
set(gcf,'Color','w');
title('(b)','fontsize',14)




CFLNs=[1 5 10];

for ii=1:3
CFLN=CFLNs(ii);

LOD3D_multistateCFLN

varlod = sprintf('energyCFLN%d', CFLN);
varana = sprintf('energyanaCFLN%d', CFLN);

eval([varlod ' = energy;']);
eval([varana ' = energyana;']);
clear energy energyana
end




dt10=dtCFL*10;
dt5=dtCFL*5;dt1=dtCFL;


nexttile
plot([dt10:dt10:dt10*length(energyCFLN10)]*1e12,real(energyCFLN10)*1000,':b','Linewidth',2);hold on
plot([dt5:dt5:dt5*length(energyCFLN5)]*1e12,real(energyCFLN5(1:length(energyCFLN5)))*1000,'--r','Linewidth',2);hold on
plot([dt1:dt1:dt1*length(energyCFLN1)]*1e12,real(energyCFLN1(1:1:length(energyCFLN1)))*1000,'k','Linewidth',2);hold on
plot([dt1:1000*dt1:dt1*length(energyCFLN1)]*1e12,real(energyanaCFLN1(1:1000:length(energyCFLN1)))*1000,'xk','Linewidth',2,'MarkerSize',8);hold on
legend('CFLN=10','CFLN=5','CFLN=1','Analytical','Location','Northwest','NumColumns',2)
xlim([0 length(energyCFLN10)]*dt10*1e12)
ylim([10.64 10.649])
xlabel('Time (ps)'); 
ylabel('Energy (meV)');
set(gca,'fontsize',14)
set(gcf,'Color','w');
title('(c)','fontsize',14)

% mainfig1.m
% source code to generate plots in Fig. 1.
% Schrodinger Equation with Gauge-Invariant Field-Impulse Replacing Potentials and Computation Using LOD-FDTD Method
% by E. L. Tan and D. Y. Heh, Aug 2025

clc; clear; close all;





ie=50;
je=50;
ke=50;



id=ie-1;     
jd=je-1;   
kd=ke-1;   

ib=ie+1;     
jb=je+1;   
kb=ke+1;



dx=1.6e-8;
dy = dx;
dz = dx;

ic=ie/2;
jc=je/2;
kc=ke/2;




x=[-ie/2:ie/2]*dx*1e6;%in micrometer
y=[-je/2:je/2]*dy*1e6;
z=[-ke/2:ke/2]*dz*1e6;


%IE data of rectangular solenoid
load IErectsolbig.mat

% Plot results

Zobs=kc;
Yobs=jc;
Xobs=ic;





figure(111)

t = tiledlayout(3,1,'TileSpacing','Compact','Padding','Compact');
set (gcf, 'Position', [10 10 1*400 1000])

[X,Y]=meshgrid(x,y);
X=interp2(X);
Y=interp2(Y);

nexttile
IEx2D=interp2(squeeze(IEx(:,:,Zobs)));
h=pcolor(X,Y,IEx2D.');
set(h, 'EdgeColor', 'none');
shading flat
axis square
grid off
box off
xlim([-ie/2 ie/2+.1]*dx*1e6)
colorbar
title('\bf(a) $I_{Ex}$','interpreter','latex','fontsize',14)
xlabel('$x$ ($\mu$m)','interpreter','latex','fontsize',14)
ylabel('$y$ ($\mu$m)','interpreter','latex','fontsize',14)
set(gca,'fontsize',14)
set(gcf,'Color','w');


nexttile
IEy2D=interp2(squeeze(IEy(:,:,Zobs)));
h=pcolor(X,Y,IEy2D.');
set(h, 'EdgeColor', 'none');
shading flat
axis square
grid off
box off
xlim([-ie/2 ie/2+.1]*dx*1e6)
colorbar
title('\bf(b) $I_{Ey}$','interpreter','latex','fontsize',14)
xlabel('$x$ ($\mu$m)','interpreter','latex','fontsize',14)
ylabel('$y$ ($\mu$m)','interpreter','latex','fontsize',14)
set(gca,'fontsize',14)
set(gcf,'Color','w');


nexttile
Bz2D=interp2(squeeze(Bz(:,:,Zobs)));
h=pcolor(X,Y,Bz2D.');
set(h, 'EdgeColor', 'none');
shading flat
axis square
grid off
box off
xlim([-ie/2 ie/2+.1]*dx*1e6)
colorbar
title('\bf(c) $B_{z}$','interpreter','latex','fontsize',14)
xlabel('$x$ ($\mu$m)','interpreter','latex','fontsize',14)
ylabel('$y$ ($\mu$m)','interpreter','latex','fontsize',14)
set(gca,'fontsize',14)
set(gcf,'Color','w');

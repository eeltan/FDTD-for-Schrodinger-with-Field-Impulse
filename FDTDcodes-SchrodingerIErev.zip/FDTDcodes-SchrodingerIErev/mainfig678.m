% mainfig678.m
% source code to generate plots in Figs. 6, 7, 8.
% Schrodinger Equation with Gauge-Invariant Field-Impulse Replacing Potentials and Computation Using LOD-FDTD Method
% by E. L. Tan and D. Y. Heh, Aug 2025

close all
clear all





LOD3D_allIE
psilod=psirecord;
prob0lod=prob0;
prob1lod=prob1;
prob2lod=prob2;

explicit3D_allIE
psiexpl=psirecord;
prob0expl=prob0;
prob1expl=prob1;
prob2expl=prob2;


dtexpl =1.935986888635174e-16;

dtlod=3.878811423610435e-15;

figure(111)

t = tiledlayout(2,1,'TileSpacing','Compact','Padding','Compact');
set (gcf, 'Position', [10 10 1*500 1*800])

% subplot(1,2,1)
nexttile
plot([dtlod:dtlod:dtlod*size(psilod,2)]*1e12,real(psilod),'k','Linewidth',2);hold on
plot([dtexpl:100*dtexpl:dtexpl*size(psiexpl,2)]*1e12,real(psiexpl(1:100:size(psiexpl,2))),'xk','Linewidth',2,'MarkerSize',8);hold on
legend('LOD-FDTD','Explicit-FDTD')
xlim([0 400]*dtlod*1e12)
ylabel('Re(\Psi)');
set(gca,'fontsize',14)
set(gcf,'Color','w');
title('(a)','fontsize',16)

% subplot(1,2,2)
nexttile
plot([dtlod:dtlod:dtlod*size(psilod,2)]*1e12,imag(psilod),'k','Linewidth',2);hold on
plot([dtexpl:100*dtexpl:dtexpl*size(psiexpl,2)]*1e12,imag(psiexpl(1:100:size(psiexpl,2))),'xk','Linewidth',2,'MarkerSize',8);hold on
% legend('LOD-FDTD','explicit FDTD')
xlim([0 400]*dtlod*1e12)
% ylim([-0.035 0.035])
xlabel('Time (ps)'); 
ylabel('Im(\Psi)');
set(gca,'fontsize',14)
set(gcf,'Color','w');
title('(b)','fontsize',16)







figure(333)

plot([dtlod:dtlod:dtlod*size(prob0lod,2)]*1e12,abs(prob0lod).^2,'k','Linewidth',2);hold on
plot([dtlod:dtlod:dtlod*size(prob1lod,2)]*1e12,abs(prob1lod).^2,'--r','Linewidth',2);hold on
plot([dtlod:dtlod:dtlod*size(prob2lod,2)]*1e12,abs(prob2lod).^2,':b','Linewidth',2);hold on

plot([dtexpl:500*dtexpl:dtexpl*size(prob0expl,2)]*1e12,abs(prob0expl(1:500:size(prob0expl,2))).^2,'xk','Linewidth',2,'MarkerSize',7);hold on
plot([dtexpl:500*dtexpl:dtexpl*size(prob1expl,2)]*1e12,abs(prob1expl(1:500:size(prob1expl,2))).^2,'xk','Linewidth',2,'MarkerSize',7);hold on
plot([dtexpl:500*dtexpl:dtexpl*size(prob2expl,2)]*1e12,abs(prob2expl(1:500:size(prob2expl,2))).^2,'xk','Linewidth',2,'MarkerSize',7);hold on

legend('LOD-FDTD (Ground state)','LOD-FDTD (Excited state 1)','LOD-FDTD (Excited state 2)', 'Explicit-FDTD')
xlim([0 400]*dtlod*1e12)
ylim([0 1.05])
xlabel('Time (ps)'); 
ylabel('Probability');
set(gca,'fontsize',14)
set(gcf,'Color','w');






x=[-ie/2:ie/2]*dx*1e9;
y=[-je/2:je/2]*dy*1e9;
z=[-ke/2:ke/2]*dz*1e9;

figure(0114)

t = tiledlayout(2,2,'TileSpacing','Compact','Padding','Compact');
set (gcf, 'Position', [10 10 1*800 700])

nexttile
[X,Y]=meshgrid(x,y);
X=interp2(X);
Y=interp2(Y);
repsitf2D=interp2(real(squeeze(psi50(:,:,ke/2))));
h=pcolor(X,Y,repsitf2D.');
set(h, 'EdgeColor', 'none');
shading flat
axis square
grid off
box off
% xlim([0 ie]*dx*1e9)
% ylim([0 je]*dy*1e9)
% clim([-3.1e11 3.1e11])
colorbar
title('\bf(a) \rm Re$(\Psi)$','interpreter','latex','fontsize',14)
xlabel('$x$ (nm)','interpreter','latex','fontsize',14)
ylabel('$y$ (nm)','interpreter','latex','fontsize',14)
set(gca,'fontsize',14)
set(gcf,'Color','w');


nexttile
[X,Y]=meshgrid(x,y);
X=interp2(X);
Y=interp2(Y);
repsitf2D=interp2(imag(squeeze(psi50(:,:,ke/2))));
h=pcolor(X,Y,repsitf2D.');
set(h, 'EdgeColor', 'none');
shading flat
axis square
grid off
box off
% xlim([0 ie]*dx*1e9)
% ylim([0 je]*dy*1e9)
clim([0 2e11])
colorbar
colorbar
title('\bf(b) \rm Im$(\Psi)$','interpreter','latex','fontsize',14)
xlabel('$x$ (nm)','interpreter','latex','fontsize',14)
ylabel('$y$ (nm)','interpreter','latex','fontsize',14)
set(gca,'fontsize',14)
set(gcf,'Color','w');



nexttile
[X,Y]=meshgrid(x,y);
X=interp2(X);
Y=interp2(Y);
repsitf2D=interp2(real(squeeze(psi292(:,:,ke/2))));
h=pcolor(X,Y,repsitf2D.');
set(h, 'EdgeColor', 'none');
shading flat
axis square
grid off
box off
% xlim([0 ie]*dx*1e9)
% ylim([0 je]*dy*1e9)
% clim([-3.1e11 3.1e11])
colorbar
title('\bf(c) \rm Re$(\Psi)$','interpreter','latex','fontsize',14)
xlabel('$x$ (nm)','interpreter','latex','fontsize',14)
ylabel('$y$ (nm)','interpreter','latex','fontsize',14)
set(gca,'fontsize',14)
set(gcf,'Color','w');


nexttile
[X,Y]=meshgrid(x,y);
X=interp2(X);
Y=interp2(Y);
repsitf2D=interp2(imag(squeeze(psi292(:,:,ke/2))));
h=pcolor(X,Y,repsitf2D.');
set(h, 'EdgeColor', 'none');
shading flat
axis square
grid off
box off
% xlim([0 ie]*dx*1e9)
% ylim([0 je]*dy*1e9)
% clim([-3.1e11 3.1e11])
colorbar
colorbar
title('\bf(d) \rm Im$(\Psi)$','interpreter','latex','fontsize',14)
xlabel('$x$ (nm)','interpreter','latex','fontsize',14)
ylabel('$y$ (nm)','interpreter','latex','fontsize',14)
set(gca,'fontsize',14)
set(gcf,'Color','w');
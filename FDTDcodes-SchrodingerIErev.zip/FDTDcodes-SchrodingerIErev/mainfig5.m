% mainfig5.m
% source code to generate plots in Fig. 5.
% Schrodinger Equation with Gauge-Invariant Field-Impulse Replacing Potentials and Computation Using LOD-FDTD Method
% by E. L. Tan and D. Y. Heh, Aug 2025

clear all
close all




% for dt slope


rarray=[-4 -3 -2 -1 0 1 2 3 4];


%lod
for rii=1:length(rarray)

rt=rarray(rii);    
LOD3D_dterr
psilod=psi;

expm3D_dterr
psiexpm=psiana;


error=psilod-psiexpm;
norm2errorlod(rii)=norm(error(:))/norm(psiexpm(:));


end


rarrayexpl=[0 1 2 3 4];

%explicit
for rii=1:length(rarrayexpl)

rt=rarrayexpl(rii); 

explicit3D_dterr
psiexpl=psi;
psiexplmid=psimid;


expm3Dexpl_dterr
psiexpm=psiana;
psiexpmmid=psimidana;

error1=psiexplmid-psiexpmmid;
error2=psiexpl-psiexpm;
norm2errorexpl(rii)=norm([error1(:);error2(:)])/norm([psiexpmmid(:);psiexpm(:)]);



end




%for dx slope

rarrays=[0 1 2 3 4];

%lod
for rii=1:length(rarrays)
    rii
rs=rarrays(rii); 
LOD3D_dxerr
error=psi-psiana;
norm2errorlods(rii)=norm(error(:))/norm(psiana(:));

end

clear psi psimid psiana


%explicit
for rii=1:length(rarrays)
    rii
rs=rarrays(rii); 
explicit3D_dxerr
error=psimid-psiana;
norm2errorexpls(rii)=norm(error(:))/norm(psiana(:));

end








t = tiledlayout(2,1,'TileSpacing','Compact','Padding','Compact');
set (gcf, 'Position', [10 10 1*500 800])

nexttile
semilogy(rarray,norm2errorlod,'k','Linewidth',2);hold on
semilogy(rarrayexpl,norm2errorexpl,'--xr','Linewidth',2,'MarkerSize',8);hold on%shift explicit parray because explicit update 2*dt in 1 n for 3 time stencil, so for fair comparison, the p should be adjusted 
legend('LOD-FDTD','Explicit-FDTD')
% xlabel('$\log_2\left(\frac{\dt_{CFL}}{\dt} \right)$','interpreter','latex','fontsize',14)
xlabel('$\log_2(\Delta t_{CFL}/\Delta t)$','interpreter','latex','fontsize',14)
ylabel('Normalized norm error');
set(gca,'fontsize',12)
set(gcf,'Color','w');
title('(a)','fontsize',16)

nexttile
semilogy(rarrays,norm2errorlods,'k','Linewidth',2);hold on
semilogy(rarrays,norm2errorexpls,'--xr','Linewidth',2,'MarkerSize',8);hold on
% legend('LOD-FDTD','explicit-FDTD')
xlabel('$\log_2(\Delta s_{ref}/\Delta s)$','interpreter','latex','fontsize',14)
ylabel('Normalized norm error');
set(gca,'fontsize',12)
set(gcf,'Color','w');
title('(b)','fontsize',16)
% LOD3D_dxerr.m
% LOD-FDTD code for Schrodinger equation, numerical examples in Fig. 5.
% Schrodinger Equation with Gauge-Invariant Field-Impulse Replacing Potentials and Computation Using LOD-FDTD Method
% by E. L. Tan and D. Y. Heh, Aug 2025

% clear all
% close all




%constants in SI
h=6.62607015e-34;
hbar=h/2/pi;
e=1.60217663e-19;
m=9.1093837e-31*0.067;%meff of GaAs is 0.067*me



% rs=0;
dx=10e-9/(2^rs);
dy=dx;
dz=dx;





ie=20*(2^rs);
je=20*(2^rs);
ke=20*(2^rs);

ib=ie+1;
jb=je+1;
kb=ke+1;

id=ie-1;
jd=je-1;
kd=ke-1;




E0=5.4e-3;%in eV
E0=E0*e;% in Joule
omega0=E0/hbar;


U0=zeros(ib,jb,kb);




Vic=round(ie/2);
Vjc=round(je/2);
Vkc=round(ke/2);

%3D harmonic oscillator
for i=1:ib
for j=1:jb
for k=1:kb

U0(i,j,k)=0.5*m*omega0^2*(((i-1-Vic)*dx)^2+((j-1-Vjc)*dy)^2+((k-1-Vkc)*dz)^2);

end
end
end




q=-e;
B0 = 10;%in Tesla
omegac=e*B0/m;
omegatot=sqrt(omega0^2+omegac^2/4);


Ieic=round(ie/2);
Iejc=round(je/2);



IEx=zeros(ib,jb,kb);
IEy=zeros(ib,jb,kb);
IEz=zeros(ib,jb,kb);




for i=1:ib
for j=1:jb
for k=1:kb

IEx(i,j,k)=B0/2*(j-1-Iejc)*dy;
IEy(i,j,k)=-B0/2*(i-1-Ieic)*dx;

end
end
end



Hkmax=hbar^2/m*(1/dx^2+1/dy^2+1/dz^2)+hbar/m*(1/dx*sqrt(hbar^2/dx^2+q^2*max(max(max(abs(IEx))))^2)+1/dy*sqrt(hbar^2/dy^2+q^2*max(max(max(abs(IEy))))^2)+1/dz*sqrt(hbar^2/dz^2+q^2*max(max(max(abs(IEz))))^2))+q^2/2/m*(max(max(max(IEx.^2)))+max(max(max(IEy.^2)))+max(max(max(IEz.^2))))+max(max(max(U0)));
Hkmin=hbar^2/m*(1/dx^2+1/dy^2+1/dz^2)-hbar/m*(1/dx*sqrt(hbar^2/dx^2+q^2*min(min(min(abs(IEx))))^2)+1/dy*sqrt(hbar^2/dy^2+q^2*min(min(min(abs(IEy))))^2)+1/dz*sqrt(hbar^2/dz^2+q^2*min(min(min(abs(IEz))))^2))+q^2/2/m*(min(min(min(IEx.^2)))+min(min(min(IEy.^2)))+min(min(min(IEz.^2))))+min(min(min(U0)));

dtCFL=hbar/(max(abs(Hkmax),abs(Hkmin)));


%use very small dt
dt=3.678993045975276e-20;
nmax=1;



psi0=zeros(ib,jb,kb);
psi0n1=zeros(ib,jb,kb);
psi01=zeros(ib,jb,kb);


% ground state
for i=2:ie
for j=2:je
for k=2:ke

psi0(i,j,k)=exp(-0.5*m*omegatot/hbar*(((i-1-Vic)*dx)^2+((j-1-Vjc)*dy)^2))*exp(-0.5*m*omega0/hbar*(((k-1-Vkc)*dz)^2));

end
end
end


% excited states 1 and 2
omegatot1=2*sqrt(omega0^2+omegac^2/4)-omegac/2;
omegatot2=2*sqrt(omega0^2+omegac^2/4)+omegac/2;
for i=2:ie
for j=2:je
for k=2:ke


psi0n1(i,j,k)=((i-1-Vic)*dx-1i*(j-1-Vjc)*dy)*exp(-0.5*m*omegatot/hbar*(((i-1-Vic)*dx)^2+((j-1-Vjc)*dy)^2))*exp(-0.5*m*omega0/hbar*(((k-1-Vkc)*dz)^2));
psi01(i,j,k)=((i-1-Vic)*dx+1i*(j-1-Vjc)*dy)*exp(-0.5*m*omegatot/hbar*(((i-1-Vic)*dx)^2+((j-1-Vjc)*dy)^2))*exp(-0.5*m*omega0/hbar*(((k-1-Vkc)*dz)^2));

end
end
end



psi0 = psi0 / sqrt( dx*dy*dz*psi0(:)' * psi0(:) ); 
psi0n1 = psi0n1 / sqrt( dx*dy*dz*psi0n1(:)' * psi0n1(:) );
psi01 = psi01 / sqrt( dx*dy*dz*psi01(:)' * psi01(:) );



psi=zeros(ib,jb,kb);
psi1=zeros(ib,jb,kb);
rho=zeros(ib,jb,kb);

psiana=zeros(ib,jb,kb);



psi=psi01;




rho = conj(psi).*psi;




tic
for n=1:nmax
n

for i=1:ib
for j=1:jb
for k=1:kb


psiana(i,j,k)=psi01(i,j,k)*exp(-1i*(omegatot2+0.5*omega0)*n*dt);


end
end
end


%1st substep
for k=2:ke
for j=2:je
for i=2:ie


a=1-dt/2*(-1i*hbar/m/dx^2-1i/hbar*(q^2/2/m*IEx(i,j,k)^2+U0(i,j,k)/3));
b=-dt/2*(1i*hbar/2/m/dx^2+q/2/m*(IEx(i,j,k)/2/dx+IEx(i-1,j,k)/2/dx));
c=-dt/2*(1i*hbar/2/m/dx^2-q/2/m*(IEx(i,j,k)/2/dx+IEx(i+1,j,k)/2/dx));

if i==2
alpha=a;
gamma(i)=c/alpha;
else
beta=b;
alpha=a;
alpha=alpha-beta*gamma(i-1);
gamma(i)=c/alpha;
end



RHS=psi(i,j,k)+dt/2*1i*hbar/2/m*((psi(i+1,j,k)-2*psi(i,j,k)+psi(i-1,j,k))/dx^2)...
    -dt/2*q/2/m*(IEx(i,j,k)*(psi(i+1,j,k)-psi(i-1,j,k))/2/dx...
                 +(IEx(i+1,j,k)*psi(i+1,j,k)-IEx(i-1,j,k)*psi(i-1,j,k))/2/dx)...
    -dt/2*1i/hbar*(q^2/2/m*IEx(i,j,k)^2*psi(i,j,k)+U0(i,j,k)/3*psi(i,j,k));

if i==2
psi1(i,j,k)=RHS/alpha;
else
psi1(i,j,k)=(RHS-beta*psi1(i-1,j,k))/alpha;
end

end

for i=id:-1:2
psi1(i,j,k)=psi1(i,j,k)-gamma(i)*psi1(i+1,j,k);
end

end
end


%2nd substep
for k=2:ke
for i=2:ie
for j=2:je


a=1-dt/2*(-1i*hbar/m/dy^2-1i/hbar*(q^2/2/m*IEy(i,j,k)^2+U0(i,j,k)/3));
b=-dt/2*(1i*hbar/2/m/dy^2+q/2/m*(IEy(i,j,k)/2/dy+IEy(i,j-1,k)/2/dy));
c=-dt/2*(1i*hbar/2/m/dy^2-q/2/m*(IEy(i,j,k)/2/dy+IEy(i,j+1,k)/2/dy));

if j==2
alpha=a;
gamma(j)=c/alpha;
else
beta=b;
alpha=a;
alpha=alpha-beta*gamma(j-1);
gamma(j)=c/alpha;
end



RHS=psi1(i,j,k)+dt/2*1i*hbar/2/m*((psi1(i,j+1,k)-2*psi1(i,j,k)+psi1(i,j-1,k))/dy^2)...
    -dt/2*q/2/m*(IEy(i,j,k)*(psi1(i,j+1,k)-psi1(i,j-1,k))/2/dy...
                 +(IEy(i,j+1,k)*psi1(i,j+1,k)-IEy(i,j-1,k)*psi1(i,j-1,k))/2/dy)...
    -dt/2*1i/hbar*(q^2/2/m*IEy(i,j,k)^2*psi1(i,j,k)+U0(i,j,k)/3*psi1(i,j,k));

if j==2
psi(i,j,k)=RHS/alpha;
else
psi(i,j,k)=(RHS-beta*psi(i,j-1,k))/alpha;
end

end

for j=jd:-1:2
psi(i,j,k)=psi(i,j,k)-gamma(j)*psi(i,j+1,k);
end

end
end




%3rd substep
for i=2:ie
for j=2:je
for k=2:ke

a=1-dt/2*(-1i*hbar/m/dz^2-1i/hbar*(q^2/2/m*IEz(i,j,k)^2+U0(i,j,k)/3));
b=-dt/2*(1i*hbar/2/m/dz^2+q/2/m*(IEz(i,j,k)/2/dz+IEz(i,j,k-1)/2/dz));
c=-dt/2*(1i*hbar/2/m/dz^2-q/2/m*(IEz(i,j,k)/2/dz+IEz(i,j,k+1)/2/dz));

if k==2
alpha=a;
gamma(k)=c/alpha;
else
beta=b;
alpha=a;
alpha=alpha-beta*gamma(k-1);
gamma(k)=c/alpha;
end



RHS=psi(i,j,k)+dt/2*1i*hbar/2/m*((psi(i,j,k+1)-2*psi(i,j,k)+psi(i,j,k-1))/dz^2)...
    -dt/2*q/2/m*(IEz(i,j,k)*(psi(i,j,k+1)-psi(i,j,k-1))/2/dz...
                 +(IEz(i,j,k+1)*psi(i,j,k+1)-IEz(i,j,k-1)*psi(i,j,k-1))/2/dz)...
    -dt/2*1i/hbar*(q^2/2/m*IEz(i,j,k)^2*psi(i,j,k)+U0(i,j,k)/3*psi(i,j,k));

if k==2
psi1(i,j,k)=RHS/alpha;
else
psi1(i,j,k)=(RHS-beta*psi1(i,j,k-1))/alpha;
end

end

for k=kd:-1:2
psi1(i,j,k)=psi1(i,j,k)-gamma(k)*psi1(i,j,k+1);
end

end
end


psi=psi1;




rho = conj(psi).*psi;




end
toc


clear all
close all


CFLNs=[100];

for ii=1:length(CFLNs)
CFLN=CFLNs(ii);

explicit3D_CPU
clear normexpl

explCPUt(ii)=toc
explerr(ii)=avgnormerr

end


CFLNs=[1 5 10 20 50];

for ii=1:length(CFLNs)
CFLN=CFLNs(ii);

LOD3D_CPU
clear normlod

LODCPUt(ii)=toc
LODerr(ii)=avgnormerr

end



